# Init for visualization
