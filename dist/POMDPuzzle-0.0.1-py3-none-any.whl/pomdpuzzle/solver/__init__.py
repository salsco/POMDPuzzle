# Init file for value iterator
